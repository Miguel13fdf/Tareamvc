/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 *
 * @author USUARIO
 */
public class DBPersona extends Persona{
     ConectPG cpg=new ConectPG();

    public DBPersona() {
    }

    public DBPersona(String id_persona, String nombres, String apellidos, int edad, Image foto, FileInputStream imagen, int largo) {
        super(id_persona, nombres, apellidos, edad, foto, imagen, largo);
    }

    
     public List<Persona> listaPersonas(String filtro) {
        try {
            //Me retorna un "List" de "persona"
            List<Persona> lista = new ArrayList<>();

            String sql = "select idpersona,nombres,apellidos,edad,foto from persona where";
            sql += " UPPER(idpersona) like UPPER('%" + filtro + "%') ";
        sql += "OR UPPER(nombres) like UPPER('%" + filtro + "%') ";
        sql += "OR UPPER(apellidos) like UPPER('%" + filtro + "%') ";

            ConectPG conpg = new ConectPG();
            ResultSet rs = conpg.consulta(sql); //La consulta nos devuelve un "ResultSet"
             byte[] bytea;

            //Pasar de "ResultSet" a "List"
            while (rs.next()) {
                //Crear las instancias de las personas
                Persona persona = new Persona();

                //Todo lo que haga en la sentencia define como voy a extraer los datos
                persona.setId_persona(rs.getString("idpersona"));
                persona.setNombres(rs.getString("nombres"));
                persona.setApellidos(rs.getString("apellidos"));
                persona.setEdad(rs.getInt("edad"));
                  //Proceso de conversion del formato de la base (Base64) a el formato Image
//               //bytea> Bytes Array
                bytea=rs.getBytes("foto");
                if (bytea!=null){
////                //Decodificando del formato de la base.(Base64)
////                
//////                bytea=Base64.decode(bytea,0,bytea.length);
                try {
                    persona.setFoto(obtenerImagen(bytea));
                } catch (IOException ex) {
                    Logger.getLogger(DBPersona.class.getName()).log(Level.SEVERE, null, ex);
                }
                }
                lista.add(persona); //Agrego los datos a la lista
            }

            //Cierro la conexion a la BD
            rs.close();
            //Retorno la lista
            return lista;

        } catch (SQLException ex) {
            Logger.getLogger(DBPersona.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
     
private Image obtenerImagen(byte[] bytes) throws IOException {
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        Iterator it = ImageIO.getImageReadersByFormatName("png");
        ImageReader reader = (ImageReader) it.next();
        Object source = bis;
        ImageInputStream iis = ImageIO.createImageInputStream(source);
        reader.setInput(iis, true);
        ImageReadParam param = reader.getDefaultReadParam();
        param.setSourceSubsampling(1, 1, 0, 0);
        return reader.read(0, param);

    }
    public boolean crearPersonaByte(){
        try {
            String sql;
            
            sql="INSERT INTO persona (idpersona,nombres,apellidos,edad,foto)";
            sql+="VALUES(?,?,?,?,?)";
            PreparedStatement ps = cpg.getCon().prepareStatement(sql);
            ps.setString(1, getId_persona());
            ps.setString(2, getNombres());
            ps.setString(3, getApellidos());
            ps.setInt(4,getEdad());
            ps.setBinaryStream(5,getImagen(),getLargo() );
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DBPersona.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
     public boolean editarPersonaByte(){
          try {
            String sql;      
            sql="UPDATE persona SET nombres=?,apellidos=?,edad=?,foto=? Where idpersona=?";
            PreparedStatement ps = cpg.getCon().prepareStatement(sql);
            ps.setString(1, getNombres());
            ps.setString(2, getApellidos());
            ps.setInt(3, getEdad());
            ps.setBinaryStream(4,getImagen(),getLargo() );
            ps.setString(5, getId_persona());
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DBPersona.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
     }

    public SQLException eliminarPersonaDB() { //eliminas la instancia en la BD

        String sql = "DELETE FROM persona WHERE idpersona = '" + getId_persona() + "';";

        ConectPG conpg = new ConectPG();

        SQLException ex = conpg.accion(sql); //Devuelve un valor de tipo "SQLException". Si devuelve 'null' esta bien, caso contrario me retornara la excepcion.
        return ex;
    }
}
