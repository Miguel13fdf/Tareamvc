/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

/**
 *
 * @author USUARIO
 */
import vista.frmListaPersona;
import modelo.DBPersona;
import controlador.CrudUsuarios;
public class mvc {
     public static void main(String[] args) {
//          VistaPersonas vista = new VistaPersonas();
//        ModeloPersona model = new ModeloPersona();
//         ViewMenuPrincipal vista = new ViewMenuPrincipal();
        
//        ControlPersona control = new ControlPersona(model, vista);
//        control.iniciacontrol();
          frmListaPersona vista= new frmListaPersona();
          DBPersona model= new DBPersona();
          CrudUsuarios control= new CrudUsuarios(model,vista);
          control.Inicar_control();
     }
    
}
