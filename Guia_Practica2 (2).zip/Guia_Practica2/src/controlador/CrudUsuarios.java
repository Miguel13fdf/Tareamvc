/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.Image;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.xml.ws.Holder;
import modelo.DBPersona;
import modelo.Persona;
import vista.frmListaPersona;

/**
 *
 * @author USUARIO
 */
public class CrudUsuarios {
     private modelo.DBPersona m;
     private  vista.frmListaPersona v;
     private JFileChooser jfc;
     private String criterio;
    public CrudUsuarios(DBPersona m, frmListaPersona v) {
        this.m = m;
        this.v = v;
        v.setVisible(true);
//        cargaPersonas();
    }
    public void Inicar_control(){
       v.getBtnActualizar().addActionListener(l->cargaPersonas()); 
        v.getBtnNuevo().addActionListener(l->abrirDialogo(1));
        v.getBtnEditar().addActionListener(l->abrirDialogo(2));
        v.getBtnAceptar().addActionListener(l->crearEditarPersonaFoto());
        v.getBtnExaminar().addActionListener(l->examinaFoto());
        v.getBtnCancelar().addActionListener(l->cancelarIngreso());
        v.getBtnEliminar().addActionListener(l->EliminarDatos());
         v.getTxtBuscar().addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buscar();
            }
        });
    }
    private void examinaFoto(){
        jfc=new JFileChooser();
        jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int estado=jfc.showOpenDialog(v);
        if(estado==JFileChooser.APPROVE_OPTION){
            try {
                Image imagen=ImageIO.read(jfc.getSelectedFile()).getScaledInstance(
                        v.getLblfoto().getWidth(),
                        v.getLblfoto().getHeight(),
                        Image.SCALE_DEFAULT);
                
                Icon icono=new ImageIcon(imagen);
                v.getLblfoto().setIcon(icono);
                v.getLblfoto().updateUI();
            } catch (IOException ex) {
                Logger.getLogger(CrudUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    private void cargaPersonas(){
       v.getTblaPersona().setDefaultRenderer(Object.class, new ImagenTabla());//La manera de renderizar la tabla.
        v.getTblaPersona().setRowHeight(100);
        
        //Enlazar el modelo de tabla con mi controlador.
        DefaultTableModel tblModel;
        tblModel=(DefaultTableModel)v.getTblaPersona().getModel();
        tblModel.setNumRows(0);//limpio filas de la tabla.

        List<Persona> listap=m.listaPersonas("");//Enlazo al Modelo y obtengo los datos
        Holder<Integer> i = new Holder<>(0);//contador para el no. fila
        listap.stream().forEach(pe->{
            
            tblModel.addRow(new Object[5]);//Creo una fila vacia/
            v.getTblaPersona().setValueAt(pe.getId_persona(), i.value, 0);
            v.getTblaPersona().setValueAt(pe.getNombres(), i.value, 1);
            v.getTblaPersona().setValueAt(pe.getApellidos(), i.value, 2);
            v.getTblaPersona().setValueAt(pe.getEdad(), i.value, 3);
             Image foto=pe.getFoto();
            if(foto!=null){
            
                Image nimg= foto.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                ImageIcon icono=new ImageIcon(nimg);
                DefaultTableCellRenderer renderer= new DefaultTableCellRenderer();
                renderer.setIcon(icono);
                v.getTblaPersona().setValueAt(new JLabel(icono), i.value, 4);
                
            }else{
                 v.getTblaPersona().setValueAt(null, i.value, 4);
            }

            i.value++;
//           String[] filap={pe.getIdPersona(),pe.getNombres(),pe.getApellidos(),"25"}; 
//           tblModel.addRow(filap);
        });
        }
    
     
       private void abrirDialogo(int ce){
            String title;
            if(ce==1){
                title="Crear nueva Persona";
                v.getDblg().setName("crear");
                //cambia el nombre del dialogo segun srea la accion realizada
                v.getDblg().setVisible(true);
                
            }else{
                title="Editar Persona";
                v.getDblg().setName("editar");
                 SacarDatos();
                 v.getTxtId().setEditable(false);
            }
            v.getDblg().setLocationRelativeTo(v);
            v.getDblg().setSize(620,270);
            v.getDblg().setTitle(title);
        }
      
       private void crearEditarPersonaFoto(){
            modelo.DBPersona persona=new modelo.DBPersona();
           if(v.getDblg().getName()=="crear"){
               persona=(modelo.DBPersona) cargarDatos();
               try {
                //Foto
                FileInputStream img=new FileInputStream(jfc.getSelectedFile());
                int largo=(int)jfc.getSelectedFile().length();
                persona.setImagen(img);
                persona.setLargo(largo);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(CrudUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
           if( persona.crearPersonaByte()){
               v.getDblg().setVisible(false);
               limpiardialogo();
               JOptionPane.showMessageDialog(v, "Persona Creada Satisfactoriamente");
           }else{
               JOptionPane.showMessageDialog(v, "No se pudo crear la persona");
           }
                 
           } else {
               if (v.getDblg().getName() == "editar") {
                
                   persona = (modelo.DBPersona) cargarDatos();
                   try {
                       //Foto
                       FileInputStream img = new FileInputStream(jfc.getSelectedFile());
                       int largo = (int) jfc.getSelectedFile().length();
                       persona.setImagen(img);
                       persona.setLargo(largo);
                   } catch (FileNotFoundException ex) {
                       Logger.getLogger(CrudUsuarios.class.getName()).log(Level.SEVERE, null, ex);
                   }
                   if(persona.editarPersonaByte()){
                        v.getDblg().setVisible(false);
                        limpiardialogo();
                     JOptionPane.showMessageDialog(v, "Persona Editada Satisfactoriamente");
                   }else{
                       JOptionPane.showMessageDialog(v, "No se pudo editar la persona"); 
                   }
               }

           }
           persona.listaPersonas("");
       }
       

       private void cancelarIngreso(){
           v.getDblg().dispose();
       }
       private void limpiardialogo(){
           v.getTxtId().setText("");
           v.getTxtNombres().setText("");
           v.getTxtApellidos().setText("");
           v.getTxtEdad().setText("");
           v.getLblfoto().setIcon(null);
       }
       private modelo.DBPersona cargarDatos(){
            modelo.DBPersona persona=new modelo.DBPersona();
            String cedula=v.getTxtId().getText();
               String nombres=v.getTxtNombres().getText();
               String apellidos=v.getTxtApellidos().getText();
               int edad=Integer.parseInt(v.getTxtEdad().getText());
               
              
               persona.setId_persona(cedula);
               persona.setNombres(nombres);
               persona.setApellidos(apellidos);
               persona.setEdad(edad);
               return persona;
           
       }

    private void SacarDatos() {
        int fila = v.getTblaPersona().getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Aun no ha seleccionado una fila");
        } else {
            String id = v.getTblaPersona().getValueAt(fila, 0).toString();
            String nombres = v.getTblaPersona().getValueAt(fila, 1).toString();
            String apellidos = v.getTblaPersona().getValueAt(fila, 2).toString();
            String edad=v.getTblaPersona().getValueAt(fila,3).toString();
            v.getTxtId().setText(id);
            v.getTxtNombres().setText(nombres);
            v.getTxtApellidos().setText(apellidos);
            v.getTxtEdad().setText(edad);
            v.getDblg().setVisible(true);
        }
              
       }
       private void EliminarDatos(){
            modelo.DBPersona personaEliminada=new modelo.DBPersona();
            int fila = v.getTblaPersona().getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Aun no ha seleccionado una fila");
        } else {

            int response = JOptionPane.showConfirmDialog(v, "¿Seguro que desea eliminar esta información?", "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {

                String cedula;
                cedula = v.getTblaPersona().getValueAt(fila, 0).toString();
                personaEliminada.setId_persona(cedula);

                if (personaEliminada.eliminarPersonaDB()==null) {
                    JOptionPane.showMessageDialog(null, "La persona fue eliminada exitosamente");
                    cargaPersonas();//Actualizo la tabla con los datos
                } else {
                    JOptionPane.showMessageDialog(null, "Error: La persona no se pudo eliminar");
                }
            }
        }
       }
       private void buscar() {
        criterio = v.getTxtBuscar().getText().trim();

        if (!criterio.equals("")) {
            llenarTablaBusqueda();
        } else {
            cargaPersonas();
        }
    }

    private void llenarTablaBusqueda() {
        DefaultTableModel estructuraTabla;
        estructuraTabla = (DefaultTableModel) v.getTblaPersona().getModel();
        estructuraTabla.setNumRows(0);
        List<Persona> listap = m.listaPersonas(criterio);

        Holder<Integer> i = new Holder<>(0);
        if (!listap.isEmpty()) {


            listap.stream().forEach(persona -> {
                estructuraTabla.addRow(new Object[3]);
                v.getTblaPersona()
                        .setValueAt(persona.getId_persona(),
                                i.value, 0);
                v.getTblaPersona()
                        .setValueAt(persona.getNombres(),
                                i.value, 1);
                v.getTblaPersona()
                        .setValueAt(persona.getApellidos(),
                                i.value, 2);
                v.getTblaPersona()
                        .setValueAt(persona.getEdad(),
                                i.value, 3);
                
                //Llenar imagen
                Image foto = persona.getFoto();
                if (foto != null) {
                    foto = foto.getScaledInstance(50, 75, Image.SCALE_SMOOTH);
                    ImageIcon icono = new ImageIcon(foto);
                    DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer();
                    dtcr.setIcon(icono);
                    v.getTblaPersona().setValueAt(new JLabel(icono), i.value, 4);

                } else {
                    v.getTblaPersona().setValueAt(null, i.value, 4);
                }
                i.value++;
            });
        } 
    }
    
}
